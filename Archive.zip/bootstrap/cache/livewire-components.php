<?php return array (
  'posts.create' => 'App\\Http\\Livewire\\Posts\\Create',
  'posts.timeline' => 'App\\Http\\Livewire\\Posts\\Timeline',
  'posts.view' => 'App\\Http\\Livewire\\Posts\\View',
  'profile.profile-page' => 'App\\Http\\Livewire\\Profile\\ProfilePage',
  'users.edit' => 'App\\Http\\Livewire\\Users\\Edit',
  'users.index' => 'App\\Http\\Livewire\\Users\\Index',
);